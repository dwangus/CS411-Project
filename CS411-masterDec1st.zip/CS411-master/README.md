# CS411
group project for CS 411


Basically a project that will allow users to find out which startups are trending in their local area.
